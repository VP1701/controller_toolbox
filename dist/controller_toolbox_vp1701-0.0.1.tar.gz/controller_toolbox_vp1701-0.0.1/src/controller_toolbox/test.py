def multiply_by_two(x):
    """Multiplies the input by two."""
    return x * 2